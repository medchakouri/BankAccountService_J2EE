package org.sid.bankaccountservice.enums;

public enum AccountType {
    CURRENT_ACCOUNT , SAVING_ACCOUNT
}
